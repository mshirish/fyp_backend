const mongoose = require("mongoose");

const BallotSchema = new mongoose.Schema(
  {

    mayor:{
      type:String,
      required:true
    },
    deputyMayor:{
      type:String,
      required:true
    },
    wardChairperson:{
      type:String,
      required:true
    },
    wardMember1:{
      type:String,
      required:true
    },
    wardMember2:{
      type:String,
      required:true
    },
    wardMember3:{
      type:String,
      required:true
    },
    wardMember4:{
      type:String,
      required:true
    },
    votedBy:{
      type: 
    }
  },
  { timestamps: true }
);
module.exports = mongoose.model("Ballot", BallotSchema);