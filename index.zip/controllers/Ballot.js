const Ballot = require('../model/Ballot')

const  giveVote = async (req,res) =>{

    try{

        const vote = await Ballot.create(req.body);
        return res
        .status(200)
        .json({ msg: `${vote} given successfully` });
    }
    catch(e){
        console.log(e);
        return res.status(400).json({msg:"couldn't give vote"})
    }

}
const getVotes = async (req,res)=>{
    try{
        const votes = await Ballot.find()
        if ((!votes || votes.length === 0)) {
            return res.status(400).json({msg:`No votes found.`})
        }
        return res.status(200).json({votes})
    }
    catch(e){
        console.log(e);
        return res.status(400).json({msg:"didn't found votes"})

    }
}
module.exports = {giveVote,getVotes}